<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => esc_html__( 'Price Table', 'bdthemes-element-pack' ),
	'required'           => true,
	'default_activation' => true,
];
