<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => 'Panel Posts Control',
	'required'           => true,
	'default_activation' => true,
];
