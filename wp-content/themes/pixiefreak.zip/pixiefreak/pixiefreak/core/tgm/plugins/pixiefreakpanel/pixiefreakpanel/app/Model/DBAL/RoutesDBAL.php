<?php

namespace PixieFreakPanel\Model\DBAL;

class RoutesDBAL
{
    use DBALTrait;
}