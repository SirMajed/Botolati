<?php

namespace PixieFreakPanel\Model;

/**
 * Interface SortableInterface
 *
 * @package pixiefreakpanel\Model
 */
interface SortableInterface
{}