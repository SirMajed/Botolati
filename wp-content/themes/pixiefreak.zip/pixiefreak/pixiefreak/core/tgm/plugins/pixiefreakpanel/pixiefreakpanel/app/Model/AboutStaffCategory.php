<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class AboutStaffCategory extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'about_staff_category';
}