<?php get_header(); ?>
<section class="single-page woocommerce">
    <div class="container">
        <?php woocommerce_content(); ?>
    </div>
</section>
<?php get_footer(); ?>