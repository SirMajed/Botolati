<aside>
    <?php if (is_active_sidebar('pixiefreak-aside-1')): ?>
        <?php dynamic_sidebar('pixiefreak-aside-1'); ?>
    <?php endif; ?>
</aside>