<form method="get" action="<?php echo site_url() ?>">
    <button type="submit"><i class="fa fa-search"></i></button>
    <input type="text" class="search_field" placeholder="<?php echo esc_attr__('Search', 'pixiefreak'); ?>" value="" name="s">
</form>